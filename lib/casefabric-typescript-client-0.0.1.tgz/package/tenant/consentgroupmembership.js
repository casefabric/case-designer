"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ConsentGroupMembership {
    constructor() {
        this.roles = [];
    }
}
exports.default = ConsentGroupMembership;
