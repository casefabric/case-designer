"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("../cmmn/cmmnbaseclass"));
class UserInformation extends cmmnbaseclass_1.default {
    constructor(userId, tenants, groups) {
        super();
        this.userId = userId;
        this.tenants = tenants;
        this.groups = groups;
    }
    ;
}
exports.default = UserInformation;
