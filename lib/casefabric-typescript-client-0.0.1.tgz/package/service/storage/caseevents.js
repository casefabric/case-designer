"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const planitem_1 = __importDefault(require("../../cmmn/planitem"));
const state_1 = __importDefault(require("../../cmmn/state"));
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
const trace_1 = __importDefault(require("../../infra/trace"));
const plan_1 = require("../../test/caseassertions/plan");
const time_1 = require("../../test/time");
const caseservice_1 = __importDefault(require("../case/caseservice"));
const planitemevents_1 = __importDefault(require("./planitemevents"));
const processevents_1 = __importDefault(require("./processevents"));
/**
 * CaseEvents enables building a hierarchy of a case events with those from it's CaseTasks and ProcessTasks.
 */
class CaseEvents extends planitemevents_1.default {
    static from(user, caseInstance) {
        const fakedItem = new planitem_1.default(caseInstance.id, caseInstance.caseName, '', 'CaseTask', caseInstance.state, '', '', false, false, 0, caseInstance.lastModified, caseInstance.createdBy);
        return new CaseEvents(user, fakedItem);
    }
    constructor(user, item, parentCase) {
        super(user, item, parentCase);
        this.user = user;
        this.parentCase = parentCase;
        this.cases = [];
        this.processes = [];
    }
    load() {
        return __awaiter(this, arguments, void 0, function* (trace = new trace_1.default()) {
            // reset state of children.
            this.cases = [];
            this.processes = [];
            if (this.state.is(state_1.default.Available)) {
                return; // no need to load more details, as the plan item is not yet active
            }
            const caseInstance = yield (0, plan_1.assertCasePlan)(this.user, this.id, undefined, trace);
            // Add sub cases
            const caseTasks = caseInstance.planitems.filter(item => item.type === 'CaseTask');
            for (const subCase of caseTasks) {
                yield this.addCase(subCase).load();
            }
            // Now add process tasks to the list
            caseInstance.planitems.filter(item => item.type === 'ProcessTask').map(item => this.processes.push(new processevents_1.default(item, this)));
        });
    }
    addCase(subCase) {
        const subCaseHierarchy = new CaseEvents(this.user, subCase, this);
        this.cases.push(subCaseHierarchy);
        return subCaseHierarchy;
    }
    findItem(name, type) {
        const matches = (task) => task.name === name && (!type || task.type === type);
        // Check if we ourselves match.
        if (matches(this))
            return this;
        // Check if one of our process tasks matches
        const processTask = this.processes.find(matches);
        if (processTask)
            return processTask;
        // Search the item in our sub cases
        for (const subCase of this.cases) {
            const task = subCase.findItem(name, type);
            if (task)
                return task;
        }
    }
    findProcessTask(name) {
        const task = this.findItem(name, 'Process');
        console.log("Found task named " + name + ": " + (task === null || task === void 0 ? void 0 : task.constructor.name));
        if (task && task instanceof processevents_1.default)
            return task;
        return undefined;
    }
    collect(collector) {
        const list = [];
        list.push(...this.cases.map(collector));
        list.push(...this.processes.map(collector));
        return list;
    }
    print(indent = '') {
        const list = this.cases.map(c => c.print(indent + ' '));
        list.push(...this.processes.map(p => p.print(indent + ' ')));
        return `${super.print(indent)}${list.length ? '\n' + list.join('\n') : ''}`;
    }
    printEvents(indent = '') {
        const list = this.cases.map(c => c.printEvents(indent + ' '));
        list.push(...this.processes.map(p => p.printEvents(indent + ' ')));
        return `${super.printEvents(indent)}${list.length ? `\n${list.join('\n')}` : ''}`;
    }
    loadEventHierarchy() {
        const _super = Object.create(null, {
            loadEvents: { get: () => super.loadEvents }
        });
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            yield _super.loadEvents.call(this, user, trace);
            const promises = [];
            this.cases.forEach(subCase => promises.push(subCase.loadEventHierarchy(user, trace)));
            this.processes.forEach(subProcess => promises.push(subProcess.loadEvents(user, trace)));
            yield Promise.all(promises);
        });
    }
    get totalEventCount() {
        return super.totalEventCount + this.collect(t => t.totalEventCount).reduce((sum, count) => sum + count, 0);
    }
    hasArchivedHierarchy() {
        if (!this.isArchived()) {
            return false;
        }
        if (this.cases.find(c => !c.hasArchivedHierarchy()))
            return false;
        return this.processes.find(p => !p.isArchived()) === undefined;
    }
    isArchived() {
        return this.hasArchiveEvent('CaseArchived');
    }
    assertArchivedHierarchy() {
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            yield (0, time_1.PollUntilSuccess)(() => __awaiter(this, void 0, void 0, function* () {
                yield this.loadEventHierarchy(user, trace);
                if (!this.hasArchivedHierarchy()) {
                    throw new asyncerror_1.default(trace, 'The case is not fully archived');
                }
            }));
        });
    }
    assertRestored() {
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            return yield (0, time_1.PollUntilSuccess)(() => __awaiter(this, void 0, void 0, function* () {
                console.log(`Checking that case ${this.id} is restored ...`);
                yield caseservice_1.default.getDiscretionaryItems(user, this.id, undefined, undefined, trace);
                yield caseservice_1.default.getCase(user, this.id, undefined, undefined, trace);
            }));
        });
    }
    assertDeleted() {
        const _super = Object.create(null, {
            assertDeleted: { get: () => super.assertDeleted }
        });
        return __awaiter(this, arguments, void 0, function* (user = this.user, trace = new trace_1.default()) {
            return _super.assertDeleted.call(this, user, trace, () => __awaiter(this, void 0, void 0, function* () { return yield this.loadEventHierarchy(user, trace); }));
        });
    }
    toString() {
        return this.print('');
    }
}
exports.default = CaseEvents;
