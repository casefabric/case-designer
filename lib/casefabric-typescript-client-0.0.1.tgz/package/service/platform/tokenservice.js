"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dateAsSeconds = dateAsSeconds;
const isomorphic_fetch_1 = __importDefault(require("isomorphic-fetch"));
const config_1 = __importDefault(require("../../config"));
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
const trace_1 = __importDefault(require("../../infra/trace"));
const logger_1 = __importDefault(require("../../logger"));
class TokenService {
    /**
     * Fetches a token for the user that has the given validity period (defaults to 2 days from now).
     *
     * @param user
     * @param issuedAt
     * @param expiresAt
     */
    static getToken(user_1) {
        return __awaiter(this, arguments, void 0, function* (user, issuer = config_1.default.TokenService.issuer, issuedAt = new Date(), expiresAt, trace = new trace_1.default()) {
            if (!expiresAt) {
                expiresAt = new Date();
                expiresAt.setDate(expiresAt.getDate() + 2);
            }
            const iss = issuer;
            const sub = user.id;
            const iat = dateAsSeconds(issuedAt);
            const exp = dateAsSeconds(expiresAt);
            const claims = { iss, sub, iat, exp };
            return this.fetchToken(claims, trace);
        });
    }
    static fetchToken(claims_1) {
        return __awaiter(this, arguments, void 0, function* (claims, trace = new trace_1.default()) {
            const object = {
                method: 'POST',
                body: JSON.stringify(claims)
            };
            if (config_1.default.TokenService.log) {
                logger_1.default.debug("Getting token " + JSON.stringify(claims, undefined, 2));
            }
            const response = yield (0, isomorphic_fetch_1.default)(config_1.default.TokenService.url, object);
            const token = yield response.text();
            if (!response.ok) {
                throw new asyncerror_1.default(trace, 'Failure in fetching token: ' + response.status + ' ' + response.statusText + '\n' + token);
            }
            return token;
        });
    }
}
exports.default = TokenService;
/**
 * Converts a date to seconds (instead of milliseconds).
 * Is needed for JWT tokens.
 * @param date
 */
function dateAsSeconds(date) {
    if (!date)
        return;
    return Math.floor(Number(date) / 1000);
}
