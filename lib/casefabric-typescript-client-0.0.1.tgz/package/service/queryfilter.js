"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extendURL = extendURL;
/**
 * Extends the url with the available parameters inside the query filter
 * @param url The url to be extended, e.g. /tasks will become /tasks?taskState=Completed&
 * @param filter QueryFilter, e.g. TaskFilter { 'taskState' : 'Completed' }
 */
function extendURL(url, filter) {
    const json = JSON.parse(JSON.stringify(filter));
    if (!url.endsWith('?'))
        url = url + '?';
    for (const field in json) {
        const value = json[field];
        url += field + '=' + value + '&';
    }
    return url;
}
