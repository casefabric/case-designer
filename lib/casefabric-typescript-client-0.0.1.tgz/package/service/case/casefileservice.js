"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
const casefileitemdocumentation_1 = __importDefault(require("../../cmmn/casefileitemdocumentation"));
const trace_1 = __importDefault(require("../../infra/trace"));
class CaseFileService {
    /**
     * Get the CaseFile of the specified case instance
     * @param Case
     * @param user
     */
    static getCaseFile(user_1, caseId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, expectedStatusCode = 200, msg = `GetCaseFile is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/casefile`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, undefined, trace);
        });
    }
    /**
     * Get the plan item's documentation
     * @param Case
     * @param user
     * @param planItemId
     */
    static getCaseFileDocumentation(user_1, caseId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, expectedStatusCode = 200, msg = `GetPlanItem is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/documentation/casefile`, user);
            return (0, response_1.checkJSONResponse)(response, msg, expectedStatusCode, [casefileitemdocumentation_1.default], trace);
        });
    }
    /**
     * Create case file item contents in the specified path
     * @param Case
     * @param user
     * @param path
     * @param data Any json structure matching the case file definition
     */
    static createCaseFileItem(user_1, caseId_1, path_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, path, data, expectedStatusCode = 200, msg = `CreateCaseFileItem is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/casefile/create/${encodeURI(path)}`, user, data);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Update case file item contents
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static updateCaseFileItem(user_1, caseId_1, path_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, path, data, expectedStatusCode = 200, msg = `UpdateCaseFileItem is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.put(`/cases/${caseId}/casefile/update/${encodeURI(path)}`, user, data);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Replace case file item contents
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static replaceCaseFileItem(user_1, caseId_1, path_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, path, data, expectedStatusCode = 200, msg = `ReplaceCaseFileItem is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.put(`/cases/${caseId}/casefile/replace/${encodeURI(path)}`, user, data);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Delete a case file item
     * @param Case
     * @param user
     * @param path
     */
    static deleteCaseFileItem(user_1, caseId_1, path_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, path, expectedStatusCode = 200, msg = `DeleteCaseFileItem is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/casefile/delete/${encodeURI(path)}`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Create case file contents
     * @param Case
     * @param user
     * @param path
     * @param data Any json structure matching the case file definition
     */
    static createCaseFile(user_1, caseId_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, data, expectedStatusCode = 200, msg = `CreateCaseFile is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/casefile/create/`, user, data);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Update case file contents
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static updateCaseFile(user_1, caseId_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, data, expectedStatusCode = 200, msg = `UpdateCaseFile is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.put(`/cases/${caseId}/casefile/update/`, user, data);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Replace case file
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static replaceCaseFile(user_1, caseId_1, data_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, data, expectedStatusCode = 200, msg = `ReplaceCaseFile is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.put(`/cases/${caseId}/casefile/replace/`, user, data);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
    /**
     * Delete entire case file
     * @param Case
     * @param user
     * @param path
     */
    static deleteCaseFile(user_1, caseId_1) {
        return __awaiter(this, arguments, void 0, function* (user, caseId, expectedStatusCode = 200, msg = `DeleteCaseFile is not expected to succeed for user ${user} in case ${caseId}`, trace = new trace_1.default()) {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/casefile/delete/`, user);
            return (0, response_1.checkResponse)(response, msg, expectedStatusCode, trace);
        });
    }
}
exports.default = CaseFileService;
