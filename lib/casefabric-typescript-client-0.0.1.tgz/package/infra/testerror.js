"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const stacktraceerror_1 = __importDefault(require("./stacktraceerror"));
class TestError extends stacktraceerror_1.default {
    constructor(error, message) {
        super(error, message, '\n');
        this.error = error;
    }
}
exports.default = TestError;
