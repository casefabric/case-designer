export default class CafienneEvent {
    type: string;
    offset: number;
    content: any;
    constructor(type: string, offset: number, content: any);
    toString(): string | undefined;
    hasType(type: string): boolean;
    get name(): string;
    get path(): string;
}
//# sourceMappingURL=cafienneevent.d.ts.map