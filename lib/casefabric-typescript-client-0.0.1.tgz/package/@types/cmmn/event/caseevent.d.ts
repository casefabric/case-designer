export default class CaseEvent {
    static readonly TaskInputFilled: string;
    static readonly HumanTaskActivated: string;
    static readonly HumanTaskInputSaved: string;
    static readonly CaseModified: string;
    static readonly DebugEvent: string;
    static readonly PlanItemCreated: string;
    static readonly PlanItemTransitioned: string;
    static readonly RepetitionRuleEvaluated: string;
    static readonly RequiredRuleEvaluated: string;
    static readonly CaseDefinitionMigrated: string;
    static readonly PlanItemMigrated: string;
    static readonly PlanItemDropped: string;
    static readonly HumanTaskDropped: string;
}
//# sourceMappingURL=caseevent.d.ts.map