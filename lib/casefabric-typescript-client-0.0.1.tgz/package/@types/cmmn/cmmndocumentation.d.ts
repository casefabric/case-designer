import CMMNBaseClass from "./cmmnbaseclass";
/**
 * JSON Wrapper for plan item documentation in a case instance
 */
export default class CMMNDocumentation extends CMMNBaseClass {
    text: string;
    textFormat: string;
    /**
     *
     * @param text Plan item id
     * @param textFormat Plan item name
     */
    constructor(text: string, textFormat: string);
}
//# sourceMappingURL=cmmndocumentation.d.ts.map