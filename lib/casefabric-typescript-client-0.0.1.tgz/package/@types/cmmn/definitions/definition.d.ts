import Trace from "../../infra/trace";
import Tenant from "../../tenant/tenant";
import User from "../../user";
export default class Definition {
    file: string;
    isDeployed: boolean;
    constructor(file: string);
    toString(): string;
    deploy(user: User, tenant: string | Tenant, trace?: Trace): Promise<void>;
}
//# sourceMappingURL=definition.d.ts.map