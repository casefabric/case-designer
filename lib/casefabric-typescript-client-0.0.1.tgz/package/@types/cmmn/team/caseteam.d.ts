import CaseTeamUser from "./caseteamuser";
import User from "../../user";
import CMMNBaseClass from "../cmmnbaseclass";
import CaseTeamGroup from "./caseteamgroup";
import CaseTeamTenantRole from "./caseteamtenantrole";
/**
 * Simple CaseTeam wrapper class.
 * Each case instance has it's own team.
 */
export default class CaseTeam extends CMMNBaseClass {
    users: CaseTeamUser[];
    groups: Array<CaseTeamGroup>;
    tenantRoles: Array<CaseTeamTenantRole>;
    caseRoles?: String[];
    unassignedRoles?: String[];
    /**
     *
     * @param users Members in this team
     * @param groups Consent Groups in this team
     */
    constructor(users: CaseTeamUser[], groups?: Array<CaseTeamGroup>, tenantRoles?: Array<CaseTeamTenantRole>);
    find(user: User): CaseTeamUser | undefined;
}
//# sourceMappingURL=caseteam.d.ts.map