export default class StackTraceError extends Error {
    constructor(error: unknown, prefix?: string, postfix?: string);
}
//# sourceMappingURL=stacktraceerror.d.ts.map