import TestCase from "../test/testcase";
export default class TestRunner {
    testClass: Function;
    isExplicitlyMentionedTest: boolean;
    name: string;
    calculatedWhitespace: string;
    test: TestCase;
    started: Date;
    ended: Date;
    summary: string;
    error: unknown;
    testNumber: number;
    running: boolean;
    completed: boolean;
    constructor(testClass: Function, isExplicitlyMentionedTest?: boolean);
    needsRunning(): boolean;
    execute(): Promise<void>;
    prepare(): Promise<void>;
    run(): Promise<void>;
    close(): Promise<void>;
    finished(): void;
    failed(error: unknown): void;
    toString(): string;
    report(): string;
}
//# sourceMappingURL=testrunner.d.ts.map