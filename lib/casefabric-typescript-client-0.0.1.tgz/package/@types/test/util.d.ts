/**
 * Few simple util functions
 */
export default class Util {
    /**
     * Simple deep-cloner for an object
     * @param object
     */
    static clone(object: any): any;
    /**
     * Generate a random string
     * @returns
     */
    static get randomString(): string;
    /**
     * Generate an id with specified pre- and postfix and inbetween a guid of the specified length, defaulting to 11
     * Note: there is no limit to length, it keeps generating strings until length is reached...
     */
    static generateId(prefix?: string, length?: number, postfix?: string): string;
    /**
     * Generate amount of ids with the prefix, length and postfix.
     */
    static generateIds(amount: number, prefix?: string, length?: number, postfix?: string): Array<string>;
    /**
     * Generate a random id, with a optional prefix and postfix
     * @param prefix
     * @param postfix
     * @returns
     */
    static generateString(prefix?: string, postfix?: string): string;
}
//# sourceMappingURL=util.d.ts.map