import Case from '../cmmn/case';
import ConsentGroup from '../service/consentgroup/consentgroup';
import Tenant from '../tenant/tenant';
/**
 * Extremely simple generic TestCase class.
 */
export default class TestCase {
    name: string;
    isDefaultTest: boolean;
    isParallelTest: boolean;
    get isSequentialTest(): boolean;
    /**
     * Identifiers will be printed in the test summary if any.
     * They can be string, or be an object that has an id field (returned from the toString() method)
     */
    identifiers: Array<string | Case | Tenant | ConsentGroup | undefined>;
    /**
     * Add an identifier for the test results summary.
     */
    addIdentifier(identifier: string | Case | Tenant | ConsentGroup | undefined): string | Tenant | ConsentGroup | Case | undefined;
    /**
     * Create a new TestCase with the given name.
     * The name can be used for logging purposes.
     */
    constructor();
    /**
     * Hook that can be implemented to setup information inside the TestCase before the run method is being invoked.
     */
    onPrepareTest(): Promise<any>;
    /**
     * Run method must be implemented inside the test case
     */
    run(): Promise<any>;
    /**
     * Hook that can be implemented to cleanup information after the run method has been invoked.
     */
    onCloseTest(): Promise<any>;
    fail(msg?: string): void;
}
//# sourceMappingURL=testcase.d.ts.map