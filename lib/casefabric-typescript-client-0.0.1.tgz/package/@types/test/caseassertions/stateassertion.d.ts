import PlanItem from "../../cmmn/planitem";
import State from "../../cmmn/state";
import Path from "../../service/case/path";
export default class StateAssertion {
    expectedState: State;
    identifier: Path;
    constructor(path: Path | string | PlanItem, expectedState: State);
    run(item: PlanItem): void;
    toString(): string;
}
//# sourceMappingURL=stateassertion.d.ts.map