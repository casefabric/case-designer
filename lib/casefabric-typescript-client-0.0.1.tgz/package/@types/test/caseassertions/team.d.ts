import Case from '../../cmmn/case';
import CaseTeam from '../../cmmn/team/caseteam';
import CaseTeamUser from '../../cmmn/team/caseteamuser';
import CaseTeamTenantRole from '../../cmmn/team/caseteamtenantrole';
import User from '../../user';
import CaseTeamGroup from '../../cmmn/team/caseteamgroup';
import Trace from '../../infra/trace';
/**
 * Asserts the case team with the given team
 * and throws error if it doesn't match
 * @param caseId
 * @param user
 * @param expectedTeam
 */
export declare function assertCaseTeam(user: User, caseId: Case | string, expectedTeam: CaseTeam, trace?: Trace): Promise<void>;
/**
 * Asserts presence of the CaseTeamUser membership in the case team
 * @param member Member that must be present
 * @param caseId Case in which the member must be present
 * @param user User that retrieves the case team
 * @param expectNoDifferences Defaults to true, but can be set to false and then checks that the member may NOT be present in the team
 */
export declare function assertCaseTeamUser(user: User, caseId: Case | string, member: CaseTeamUser, expectNoDifferences?: boolean, trace?: Trace): Promise<void>;
/**
 * Asserts presence of the CaseTeamTenantRole membership in the case team
 * @param member Member that must be present
 * @param caseId Case in which the member must be present
 * @param user User that retrieves the case team
 * @param expectNoDifferences Defaults to true, but can be set to false and then checks that the member may NOT be present in the team
 */
export declare function assertCaseTeamTenantRole(user: User, caseId: Case | string, member: CaseTeamTenantRole, expectNoDifferences?: boolean, trace?: Trace): Promise<void>;
/**
 * Asserts presence of the CaseTeamGroup membership in the case team
 * @param member Member that must be present
 * @param caseId Case in which the member must be present
 * @param user User that retrieves the case team
 * @param expectNoDifferences Defaults to true, but can be set to false and then checks that the member may NOT be present in the team
 */
export declare function assertSameCaseTeamGroup(user: User, caseId: Case | string, member: CaseTeamGroup, expectNoDifferences?: boolean, trace?: Trace): Promise<void>;
//# sourceMappingURL=team.d.ts.map