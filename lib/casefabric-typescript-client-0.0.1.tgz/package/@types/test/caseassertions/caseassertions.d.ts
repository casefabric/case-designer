import Case from "../../cmmn/case";
import State from "../../cmmn/state";
import Path from "../../service/case/path";
import User from "../../user";
import StateAssertion from "./stateassertion";
/**
 * CaseAssertions enables building a hierarchy of a case with it's sub cases, and setting multiple assertions on the case and it's subcases.
 * When assertions are available, we call the runAssertions() method, which will poll until all assertions are true, or give timeout.
 */
export default class CaseAssertions {
    user: User;
    private identifier?;
    private parentCase?;
    static from(user: User, caseInstance: Case): CaseAssertions;
    id?: string;
    stateAssertions: Array<StateAssertion>;
    caseInstance?: Case;
    private subCaseAssertions;
    private constructor();
    get items(): import("../..").PlanItem[];
    /**
     * Shortcut to retrieving a plan item from the most recently fetched case instance.
     * If the case instance has not been fetched, this will throw an error.
     */
    findItem(path: Path | string, msg?: string): import("../..").PlanItem;
    /**
     * If the case has a CaseTask, this method can be used to create assertions on the sub case implementing the CaseTask.
     * Note: when the assertions of the main case are ran, this will implicitly assert that the sub case exists.
     */
    assertSubCase(path: Path | string): CaseAssertions;
    /**
     * Add an assertion on the plan item with the specified path to have the expected state
     */
    assertPlanItemState(path: Path | string, expectedState: State): StateAssertion;
    /**
     * Asynchronously fetch case instance(s) and run all assertions until they succeed.
     */
    runAssertions(): Promise<void>;
    private refreshCaseInstance;
    private run;
}
//# sourceMappingURL=caseassertions.d.ts.map