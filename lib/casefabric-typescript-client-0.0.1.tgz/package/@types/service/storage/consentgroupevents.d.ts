import ActorEvents from "./actorevents";
export default class ConsentGroupEvents extends ActorEvents {
}
//# sourceMappingURL=consentgroupevents.d.ts.map