import PlanItem from "../../cmmn/planitem";
import State from "../../cmmn/state";
import Trace from "../../infra/trace";
import User from "../../user";
import ActorEvents from "./actorevents";
import CaseEvents from "./caseevents";
export default class PlanItemEvents extends ActorEvents {
    user: User;
    parentCase?: CaseEvents | undefined;
    state: State;
    constructor(user: User, item: PlanItem, parentCase?: CaseEvents | undefined);
    assertArchived(user?: User, trace?: Trace): Promise<any>;
    protected hasArchiveEvent(archiveEventName: string): boolean;
    isArchived(): boolean;
}
//# sourceMappingURL=planitemevents.d.ts.map