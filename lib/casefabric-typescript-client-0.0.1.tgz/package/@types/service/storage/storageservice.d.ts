import Case from "../../cmmn/case";
import Trace from "../../infra/trace";
import Tenant from "../../tenant/tenant";
import User from "../../user";
/**
 * Connection to the /storage APIs of Cafienne
 */
export default class StorageService {
    /**
     * Deletes the case on behalf of the user. User must be a tenant owner.
     * @param user
     * @param caseInstance
     * @param expectedStatusCode
     */
    static archiveCase(user: User, caseInstance: Case | string, expectedStatusCode?: number, errorMsg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     * Deletes the case on behalf of the user. User must be a tenant owner.
     * @param user
     * @param caseInstance
     * @param expectedStatusCode
     */
    static restoreCase(user: User, caseInstance: Case | string, expectedStatusCode?: number, errorMsg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     * Deletes the case on behalf of the user. User must be a tenant owner.
     * @param user
     * @param caseInstance
     * @param expectedStatusCode
     */
    static deleteCase(user: User, caseInstance: Case | string, expectedStatusCode?: number, errorMsg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     * Deletes the tenant on behalf of the user. User must be a tenant owner.
     * @param user
     * @param tenant
     * @param expectedStatusCode
     */
    static deleteTenant(user: User, tenant: Tenant | string, expectedStatusCode?: number, errorMsg?: string, trace?: Trace): Promise<import("../response").default>;
}
//# sourceMappingURL=storageservice.d.ts.map