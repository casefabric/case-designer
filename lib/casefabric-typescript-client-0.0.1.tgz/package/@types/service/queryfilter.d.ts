/**
 * Base for QueryFilters. Queries to the case services can be extended with optional parameters.
 * See also: @TaskFilter and @link CaseFilter.
 */
export default interface QueryFilter {
}
/**
 * Extends the url with the available parameters inside the query filter
 * @param url The url to be extended, e.g. /tasks will become /tasks?taskState=Completed&
 * @param filter QueryFilter, e.g. TaskFilter { 'taskState' : 'Completed' }
 */
export declare function extendURL(url: string, filter: QueryFilter): string;
//# sourceMappingURL=queryfilter.d.ts.map