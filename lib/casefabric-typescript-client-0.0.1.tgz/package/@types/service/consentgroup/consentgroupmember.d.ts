import User from "../../user";
export default class ConsentGroupMember extends User {
    userId: string;
    roles: Array<string>;
    isOwner: boolean;
    /**
     * Simple wrapper for a ConsentGroup member.
     * It needs a userId, which must match the 'sub' inside the JWT token sent to the case engine.
     * The class User has an id, and this id is put inside the 'sub' of the token when the user logs in.
     *
     * @param userId Typically filled from User.id.
     * @param roles Set of strings containing the names of the roles the user has within the tenant.
     * @param isOwner Optional flag to indicate that this user is a tenant owner
     */
    constructor(userId: string, roles?: Array<string>, isOwner?: boolean);
    toJson(): {
        userId: string;
        roles: string[];
        isOwner: boolean;
    };
    /**
     * Copies this user info, with overwriting the ownership with the given value
     * @param isOwner
     * @returns
     */
    withOwnership(isOwner: boolean): ConsentGroupMember;
    /**
     * Copies this user info, with overwriting the roles with the new set
     * @param roles
     * @returns
     */
    withRoles(...roles: Array<string>): ConsentGroupMember;
    withExtraRoles(...roles: Array<string>): ConsentGroupMember;
}
export declare class ConsentGroupOwner extends ConsentGroupMember {
    userId: string;
    roles: Array<string>;
    constructor(userId: string, roles?: Array<string>);
}
//# sourceMappingURL=consentgroupmember.d.ts.map