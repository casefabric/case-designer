import Trace from '../../infra/trace';
import Tenant from '../../tenant/tenant';
import User from '../../user';
import ConsentGroup from './consentgroup';
import ConsentGroupMember from './consentgroupmember';
/**
 * Connection to the /consent-group APIs of Cafienne
 */
export default class ConsentGroupService {
    /**
     * Creates the consent group
     * @param user
     * @param tenant
     * @param group
     * @param expectedStatusCode
     * @returns
     */
    static createGroup(user: User, tenant: Tenant | string, group: ConsentGroup, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<void | import("../response").default>;
    /**
     * Retrieve a consent group with it's members
     * @param user Must be a valid user in the group
     * @param groupId
     * @param expectedStatusCode
     */
    static getGroup(user: User, groupId: ConsentGroup | string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<ConsentGroup>;
    /**
     * Replaces the consent group
     * @param user
     * @param tenant
     * @param group
     * @param expectedStatusCode
     * @returns
     */
    static replaceGroup(user: User, group: ConsentGroup, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     * Retrieve information about a specific user in the group
     * @param user Must be a group user
     * @param groupId
     * @param userId User or Id of the user to retrieve the information for
     * @param expectedStatusCode
     */
    static getGroupMember(user: User, groupId: ConsentGroup | string, userId: User | string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<ConsentGroupMember>;
    /**
     * Add or replace a user in the group
     * @param user Must be a group owner
     * @param groupId Group in which to add/replace the member.
     * @param newUser The new user information that will be updated
     * @param expectedStatusCode
     */
    static setGroupMember(user: User, groupId: ConsentGroup | string, newUser: ConsentGroupMember, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     *
     * @param user Must be a group owner
     * @param groupId Group to remove the member from
     * @param userId User or id of user to be removed from the group.
     * @param expectedStatusCode
     * @returns
     */
    static removeGroupMember(user: User, groupId: ConsentGroup | string, userId: User | string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<import("../response").default>;
}
//# sourceMappingURL=consentgroupservice.d.ts.map