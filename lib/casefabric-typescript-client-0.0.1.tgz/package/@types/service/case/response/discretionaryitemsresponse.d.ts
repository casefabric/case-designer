import CMMNBaseClass from "../../../cmmn/cmmnbaseclass";
import DiscretionaryItem from "../../../cmmn/discretionaryitem";
/**
 * Simple JSON interface wrapper
 */
export declare class DiscretionaryItemsResponse extends CMMNBaseClass {
    caseInstanceId: string;
    name: string;
    discretionaryItems: Array<DiscretionaryItem>;
    constructor(caseInstanceId: string, name: string, discretionaryItems: Array<DiscretionaryItem>);
}
//# sourceMappingURL=discretionaryitemsresponse.d.ts.map