import Case from "../../cmmn/case";
import PlanItemHistory from "../../cmmn/planitemhistory";
import Trace from "../../infra/trace";
import User from "../../user";
export default class CaseHistoryService {
    /**
     * Get the history of all plan items in the case
     * @param Case
     * @param user
     */
    static getCasePlanHistory(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<Array<PlanItemHistory>>;
    /**
     * Get the history of the plan item
     * @param Case
     * @param user
     * @param planItemId
     */
    static getPlanItemHistory(user: User, caseId: Case | string, planItemId: string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<Array<PlanItemHistory>>;
}
//# sourceMappingURL=casehistoryservice.d.ts.map