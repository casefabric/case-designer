import User from "../../user";
import Case from "../../cmmn/case";
import PlanItem from "../../cmmn/planitem";
import CMMNDocumentation from "../../cmmn/cmmndocumentation";
import Transition from "../../cmmn/transition";
import Trace from "../../infra/trace";
export default class CasePlanService {
    /**
     * Get the list of plan items of the case instance
     * @param Case
     * @param user
     */
    static getPlanItems(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<Array<PlanItem>>;
    /**
     * Get the plan item
     * @param Case
     * @param user
     * @param planItemId
     */
    static getPlanItem(user: User, caseId: Case | string, planItemId: string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<PlanItem>;
    /**
     * Get the plan item's documentation
     * @param Case
     * @param user
     * @param planItemId
     */
    static getPlanItemDocumentation(user: User, caseId: Case | string, planItemId: string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<CMMNDocumentation>;
    /**
     * Tell the plan item to make the specified transition
     * @param Case
     * @param user
     * @param planItemId
     */
    static makePlanItemTransition(user: User, caseId: Case | string, planItemId: string, transition: Transition, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<import("../response").default>;
    /**
     * Tell the event to occur
     * @param Case
     * @param user
     * @param eventName
     */
    static raiseEvent(user: User, caseId: Case | string, eventName: string, expectedStatusCode?: number, msg?: string, trace?: Trace): Promise<import("../response").default>;
}
//# sourceMappingURL=caseplanservice.d.ts.map