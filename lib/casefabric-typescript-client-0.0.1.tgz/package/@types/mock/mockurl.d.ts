import { Request, Response } from 'express';
import { OutgoingHttpHeaders } from 'http';
import MockServer from './mockserver';
export default class MockURL {
    mockServer: MockServer;
    url: string;
    private callback;
    timeout: number;
    private calls;
    constructor(mockServer: MockServer, url: string, callback: (call: MockInvocation) => void, timeout?: number);
    untilCallInvoked(millis?: number): Promise<unknown>;
    /**
     *
     * @param response
     */
    syncPromise(response: any): void;
    register(): void;
    get method(): string;
    handleRoute(req: Request, res: Response, next: Function): void;
    addRoute(): void;
}
export declare class MockInvocation {
    req: Request;
    res: Response;
    next: Function;
    mock: MockURL;
    private __syncMessage;
    constructor(req: Request, res: Response, next: Function, mock: MockURL);
    /**
     * Sets the sync message that will be returned for calls to untilCallInvoked on the Mock endpoint
     * @param msg
     */
    setSyncMessage(msg: any): void;
    writeHead(statusCode: number, headers?: OutgoingHttpHeaders): void;
    onContent(callback: Function): void;
    onJSONContent(callback: Function): void;
    write(content: any): void;
    fail(statusCode: number, content: any): void;
    json(content?: any): void;
    end(): void;
}
//# sourceMappingURL=mockurl.d.ts.map