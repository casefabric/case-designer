import ConsentGroup from "../../service/consentgroup/consentgroup";
import Tenant from "../../tenant/tenant";
import TenantUser from "../../tenant/tenantuser";
import User from "../../user";
export default class RandomTenant extends Tenant {
    private owner?;
    private groups;
    constructor(prefix?: string, users?: Array<TenantUser>);
    addUser<T extends TenantUser>(user: T): T;
    create(platformOwner: User): Promise<void>;
    /**
     * Add a group that is owned by at least the tenant owner.
     * @param group
     */
    addGroup<G extends ConsentGroup>(group: G): G;
    /**
     * Add a group that is owned by at least the tenant owner.
     * @param group
     */
    createGroup(group: ConsentGroup): Promise<void>;
}
//# sourceMappingURL=randomtenant.d.ts.map