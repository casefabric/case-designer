import User from "../../user";
import TenantUser, { TenantOwner } from "../../tenant/tenantuser";
import Tenant from "../../tenant/tenant";
/**
 * Simple test tenant to avoid duplicate code
 */
export default class WorldWideTestTenant {
    readonly name: string;
    platformAdmin: User;
    static defaultTenantName: string;
    private wrapper;
    get sender(): TenantOwner;
    get receiver(): TenantOwner;
    get employee(): TenantUser;
    get tenant(): Tenant;
    constructor(name?: string, platformAdmin?: User);
    /**
     * Creates the tenant, and logs in for sender user and receiver user.
     */
    create(): Promise<void>;
    /**
     * Resets and clears any cached information on the creation of this tenant.
     * This is typically invoked from the StorageService upon successfull tenant deletion.
     * @param tenant
     */
    static reset(tenant: Tenant | string): void;
}
//# sourceMappingURL=worldwidetesttenant.d.ts.map