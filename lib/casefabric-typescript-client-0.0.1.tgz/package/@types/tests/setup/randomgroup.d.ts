import ConsentGroup from "../../service/consentgroup/consentgroup";
import ConsentGroupMember from "../../service/consentgroup/consentgroupmember";
import User from "../../user";
export default class RandomGroup extends ConsentGroup {
    constructor(prefix?: string, members?: Array<ConsentGroupMember>);
    addMember(user?: User, roles?: Array<string>): ConsentGroupMember;
}
//# sourceMappingURL=randomgroup.d.ts.map