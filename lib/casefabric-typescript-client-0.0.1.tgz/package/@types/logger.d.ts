export default class logger {
    static endGroup(): void;
    static debug(msg?: string): void;
    static info(msg?: string, startGroup?: boolean): void;
    static warn(msg?: string): void;
    static error(msg?: string): void;
    static get debugEnabled(): boolean;
    static get infoEnabled(): boolean;
    static get warnEnabled(): boolean;
    static get errorEnabled(): boolean;
}
//# sourceMappingURL=logger.d.ts.map