import TenantUser from "./tenantuser";
export default class Tenant {
    name: string;
    users: TenantUser[];
    /**
     * Simple wrapper class for Tenant.
     * @param name Name (and id) of the tenant.
     * @param users List of Tenant Users in the tenant.
     */
    constructor(name: string, users: TenantUser[]);
    /**
     * Returns the tenant users that are owner.
     */
    getOwners(): TenantUser[];
    toJson(): {
        name: string;
        users: (TenantUser | {
            userId: string;
            roles: string[];
            name: string | undefined;
            email: string | undefined;
            isOwner: boolean;
            enabled: boolean;
        })[];
    };
    toString(): string;
}
//# sourceMappingURL=tenant.d.ts.map