"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("./cmmnbaseclass"));
/**
 * Wrapper for the discretionary items of a case.
 */
class DiscretionaryItem extends cmmnbaseclass_1.default {
    /**
     *
     * @param name Name of the discretionary item
     * @param definitionId ID of the discretionary item inside the case definition
     * @param type Type of item (e.g., HumanTask or Stage)
     * @param parentName Name of the parent of the item (either the HumanTask or the Stage in which it is declared)
     * @param parentType Type of parent in which the item is declared (stage or humantask)
     * @param parentId Plan item id of the parent declaring the discretionary item
     */
    constructor(name, definitionId, type, parentName, parentType, parentId) {
        super();
        this.name = name;
        this.definitionId = definitionId;
        this.type = type;
        this.parentName = parentName;
        this.parentType = parentType;
        this.parentId = parentId;
    }
}
exports.default = DiscretionaryItem;
