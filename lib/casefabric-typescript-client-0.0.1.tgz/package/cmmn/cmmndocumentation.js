"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("./cmmnbaseclass"));
/**
 * JSON Wrapper for plan item documentation in a case instance
 */
class CMMNDocumentation extends cmmnbaseclass_1.default {
    /**
     *
     * @param text Plan item id
     * @param textFormat Plan item name
     */
    constructor(text, textFormat) {
        super();
        this.text = text;
        this.textFormat = textFormat;
    }
}
exports.default = CMMNDocumentation;
