"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("./cmmnbaseclass"));
const path_1 = __importDefault(require("../service/case/path"));
/**
 * Wrapper for json response of Cafienne Service for a single case instance.
 */
class Case extends cmmnbaseclass_1.default {
    /**
     *
     * @param id ID of the case
     * @param tenant Tenant in which the case resides
     * @param caseName Name of the case (taken from the definition)
     * @param state State of the case (taken from case plan)
     * @param failures Number of failures (plan items in state Failed) in this case
     * @param parentCaseId Id of parent case; is null or empty if there is no parent case
     * @param rootCaseId Id of the top most ancestor case. Is equal to the case id if there is no parent case
     * @param createdOn Timestamp of case creation
     * @param createdBy Id of user that created the case
     * @param lastModified Timestamp of last modification to the case
     * @param modifiedBy Id of user that last modified the case
     * @param team Array of members that form the case team
     * @param planitems List of all planitems created (or planned) inside the case
     * @param file JSON structor of the case file
     */
    constructor(id, tenant, caseName, state, failures, parentCaseId, rootCaseId, createdOn, createdBy, lastModified, modifiedBy, 
    // Apparently input and output parameters of a case are not stored yet?!
    // public inputs: object,
    // public outputs: object,
    team, planitems, file) {
        super();
        this.id = id;
        this.tenant = tenant;
        this.caseName = caseName;
        this.state = state;
        this.failures = failures;
        this.parentCaseId = parentCaseId;
        this.rootCaseId = rootCaseId;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.lastModified = lastModified;
        this.modifiedBy = modifiedBy;
        this.team = team;
        this.planitems = planitems;
        this.file = file;
    }
    get plan() {
        const caseplan = this.planitems.find(item => item.type === 'CasePlan');
        if (!caseplan) {
            throw new Error(`Could not find case plan among the ${this.planitems.length} items in the case`);
        }
        return caseplan;
    }
    toString() {
        return this.id;
    }
    /**
     * Returns the plan item matching the path, or throws an error
     * @param path - The path to resolve on the plan item structure of the case
     */
    findItem(path) {
        const item = path_1.default.from(path).resolve(this);
        if (!item) {
            throw new Error(`Expected a plan item ${path} to be present in the case, but it cannot be found`);
        }
        return item;
    }
    printPlan() {
        class Wrapper {
            constructor(item) {
                this.item = item;
                this.children = [];
            }
            print(indent = '') {
                const item = this.item;
                const string = `${indent}- ${item.type}[${item.name}.${item.index}] | state = ${item.currentState} | transition = ${item.transition} | id = ${item.id}\n`;
                return string + this.children.map(child => child.print(indent + ' ')).join('');
            }
        }
        const stages = this.planitems.filter(item => item.type === 'Stage' || item.type === 'CasePlan').map(item => new Wrapper(item));
        const wrappers = this.planitems.filter(item => item.type !== 'Stage' && item.type !== 'CasePlan').map(item => {
            var _a;
            const wrapper = new Wrapper(item);
            if (item.stageId) {
                wrapper.stage = stages.find(stage => stage.item.id === item.stageId);
                (_a = wrapper.stage) === null || _a === void 0 ? void 0 : _a.children.push(wrapper);
            }
            return wrapper;
        });
        stages.forEach(wrapper => {
            var _a;
            if (wrapper.item.type === 'Stage') {
                wrapper.stage = stages.find(stage => stage.item.id === wrapper.item.stageId);
                (_a = wrapper.stage) === null || _a === void 0 ? void 0 : _a.children.push(wrapper);
            }
        });
        const cp = stages.find(wrapper => wrapper.item.type === 'CasePlan');
        if (cp) {
            return cp.print();
        }
        else {
            return 'Cannot print the plan items of the case as it does not contain a case plan';
        }
    }
}
exports.default = Case;
