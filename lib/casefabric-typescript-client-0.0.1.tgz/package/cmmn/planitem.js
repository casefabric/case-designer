"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("./cmmnbaseclass"));
/**
 * JSON Wrapper for plan items in a case instance
 */
class PlanItem extends cmmnbaseclass_1.default {
    /**
     *
     * @param id Plan item id
     * @param name Plan item name
     * @param stageId Id of the stage to which this plan item belongs, or empty if it is the CasePlan itself.
     * @param type Type of plan item. E.g. HumanTask, Milestone, Stage, TimerEvent, UserEvent, ProcessTask, CaseTask, CasePlan.
     * @param currentState Current state of plan item. E.g. Available, Active, Completed, Terminated, Suspended, Failed
     * @param historyState Previous state of the plan item
     * @param transition Transition through which the plan item reached current state. E.g., create, start, complete, fault, exit, etc.
     * @param isRequired Indicates whether this plan item is required in order for it's parent stage to be able to complete
     * @param isRepeating Indicates whether a new instance of this plan item must be created when this one completes or terminates.
     * @param index If a plan item repeats, index gives the instance version, starting off 0
     * @param lastModified Timestamp when the plan item was last modified
     * @param modifiedBy Id of user that caused last modification on the plan item.
     */
    constructor(id, name, stageId, type, currentState, historyState, transition, isRequired, isRepeating, index, lastModified, modifiedBy) {
        super();
        this.id = id;
        this.name = name;
        this.stageId = stageId;
        this.type = type;
        this.currentState = currentState;
        this.historyState = historyState;
        this.transition = transition;
        this.isRequired = isRequired;
        this.isRepeating = isRepeating;
        this.index = index;
        this.lastModified = lastModified;
        this.modifiedBy = modifiedBy;
    }
}
exports.default = PlanItem;
