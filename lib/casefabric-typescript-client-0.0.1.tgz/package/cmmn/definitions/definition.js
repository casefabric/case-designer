"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const trace_1 = __importDefault(require("../../infra/trace"));
const repositoryservice_1 = __importDefault(require("../../service/case/repositoryservice"));
class Definition {
    constructor(file) {
        this.file = file;
        this.isDeployed = false;
    }
    toString() {
        return this.file;
    }
    deploy(user_1, tenant_1) {
        return __awaiter(this, arguments, void 0, function* (user, tenant, trace = new trace_1.default()) {
            if (!this.isDeployed) {
                yield repositoryservice_1.default.validateAndDeploy(user, this.file, tenant, trace);
            }
            this.isDeployed = true;
        });
    }
}
exports.default = Definition;
