"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("../cmmnbaseclass"));
/**
 * Simple CaseTeam wrapper class.
 * Each case instance has it's own team.
 */
class CaseTeam extends cmmnbaseclass_1.default {
    /**
     *
     * @param users Members in this team
     * @param groups Consent Groups in this team
     */
    constructor(users, groups = [], tenantRoles = []) {
        super();
        this.users = users;
        this.groups = groups;
        this.tenantRoles = tenantRoles;
        this.caseRoles = undefined;
        this.unassignedRoles = undefined;
    }
    find(user) {
        return this.users.find(member => member.userId === user.id);
    }
}
exports.default = CaseTeam;
