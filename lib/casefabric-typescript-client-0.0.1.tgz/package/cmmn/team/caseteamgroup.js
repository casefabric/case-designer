"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupRoleMappingWithCaseOwnership = exports.GroupRoleMapping = void 0;
const cmmnbaseclass_1 = __importDefault(require("../cmmnbaseclass"));
class CaseTeamGroup extends cmmnbaseclass_1.default {
    /**
     * Base case team member, supporting all types (tenant-user vs. tenant-role and whether case owner or not)
     * @param user Either a String or a User, holding the user id of the case team member
     * @param roles Set of roles that the user has within this case team; if not given, then the roles of the user are used (if any)
     * @param memberType The type of member (either a 'user' or a 'role')
     * @param isOwner Whether or not the new member is also a Case Owner
     */
    constructor(group, mappings = []) {
        super();
        this.mappings = mappings;
        this.groupId = '' + group;
    }
    toString() {
        return this.groupId;
    }
}
exports.default = CaseTeamGroup;
class GroupRoleMapping {
    constructor(groupRole, caseRoleList) {
        this.groupRole = groupRole;
        this.isOwner = false;
        this.caseRoles = [];
        this.caseRoles = typeof caseRoleList === 'string' ? [caseRoleList] : caseRoleList;
    }
}
exports.GroupRoleMapping = GroupRoleMapping;
class GroupRoleMappingWithCaseOwnership extends GroupRoleMapping {
    constructor(groupRole, caseRoleList) {
        super(groupRole, caseRoleList);
        this.groupRole = groupRole;
        this.isOwner = true;
    }
}
exports.GroupRoleMappingWithCaseOwnership = GroupRoleMappingWithCaseOwnership;
