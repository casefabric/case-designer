"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CaseOwner = void 0;
const cmmnbaseclass_1 = __importDefault(require("../cmmnbaseclass"));
class CaseTeamUser extends cmmnbaseclass_1.default {
    /**
     * Base case team member, supporting all types (tenant-user vs. tenant-role and whether case owner or not)
     * @param user Either a String or a User, holding the user id of the case team member
     * @param caseRoles Set of roles that the user has within this case team; if not given, then the roles of the user are used (if any)
     */
    constructor(user, caseRoles = []) {
        super();
        this.caseRoles = caseRoles;
        this.isOwner = undefined;
        this.userId = user.toString();
    }
    toString() {
        return this.userId;
    }
}
exports.default = CaseTeamUser;
class CaseOwner extends CaseTeamUser {
    /**
     * Create a case team member that is also owner to the case
     * @param user Either a String or a User, holding the user id of the case team member
     * @param caseRoles Set of roles that the user has within this case team; if not given, then the roles of the user are used (if any)
     */
    constructor(user, caseRoles = []) {
        super(user, caseRoles);
        this.caseRoles = caseRoles;
        this.isOwner = true;
    }
}
exports.CaseOwner = CaseOwner;
