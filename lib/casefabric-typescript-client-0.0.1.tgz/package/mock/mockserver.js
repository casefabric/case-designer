"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const config_1 = __importDefault(require("../config"));
const logger_1 = __importDefault(require("../logger"));
const server_destroy_1 = __importDefault(require("server-destroy"));
/**
 * Simple mock service, leveraging Express to handle POST and GET requests,
 * It has an in-memory "synchronization" mechanism through which it is possible to see if the mock is actually being invoked, including a timeout mechanism.
 * In order to use the mock service, for each end point you need to register a MockURL (e.g. a PostMock or a GetMock). This Mock must also be used for the synchronization.
 * Note that the same mock can be used for multiple calls to the end point, and it keeps track of the number of calls, including the number of waits for a call.
 * Also currently it allows to start/stop the Express service, but there is no state cleanup for it (and no testcase using it either).
 */
class MockServer {
    constructor(port) {
        this.port = port;
        this.mocks = [];
        this.expressWrapper = getExpressWrapper(port);
    }
    /**
     * Returns express() on which URL listeners can be registered.
     */
    get express() {
        return this.expressWrapper.express;
    }
    /**
     * Open the port (if not yet done), and register our mocks
     */
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            this.expressWrapper.start();
            this.mocks.forEach(mock => mock.register());
        });
    }
    /**
     * Stop the mock server
     */
    stop() {
        return __awaiter(this, void 0, void 0, function* () {
            this.expressWrapper.stop();
        });
    }
}
exports.default = MockServer;
function getExpressWrapper(port) {
    const wrapper = expressWrappers.find(wrapper => wrapper.port === port) || new ExpressWrapper(port);
    if (expressWrappers.indexOf(wrapper) < 0) {
        expressWrappers.push(wrapper);
    }
    return wrapper;
}
function removeExpressWrapper(wrapper) {
    if (expressWrappers.indexOf(wrapper) >= 0) {
        expressWrappers.splice(expressWrappers.indexOf(wrapper), 1);
    }
}
const expressWrappers = [];
class ExpressWrapper {
    constructor(port) {
        this.port = port;
        this.express = (0, express_1.default)();
        this.isStarted = false;
    }
    start() {
        if (this.isStarted) {
            // No need to start again that's already done.
            return;
        }
        this.server = this.express.listen(this.port, () => {
            if (config_1.default.MockService.registration) {
                logger_1.default.info("Started Mock Server on port " + this.port);
            }
        });
        this.isStarted = true;
        (0, server_destroy_1.default)(this.server);
    }
    stop() {
        if (config_1.default.MockService.registration) {
            logger_1.default.info("Stopping Mock server on port " + this.port);
        }
        const port = this.port;
        this.server.destroy(function (err) {
            if (err) {
                logger_1.default.info(`Failure while shutting down mock server on port ${port}: ${err.message}`);
            }
            else {
                logger_1.default.info(`Mock server on port ${port} is stopped`);
            }
        });
        removeExpressWrapper(this);
    }
}
