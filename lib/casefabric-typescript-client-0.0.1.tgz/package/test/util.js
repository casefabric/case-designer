"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Few simple util functions
 */
class Util {
    /**
     * Simple deep-cloner for an object
     * @param object
     */
    static clone(object) {
        return JSON.parse(JSON.stringify(object));
    }
    /**
     * Generate a random string
     * @returns
     */
    static get randomString() {
        // toString(36) generates numbers [0...9] and letters [a...z]
        // Substring(2, 14) removes "0." prefix at the beginning, resulting in a string of length 11.
        return Math.random().toString(36).substring(2, 14) + Math.random().toString(36).substring(2, 14);
    }
    /**
     * Generate an id with specified pre- and postfix and inbetween a guid of the specified length, defaulting to 11
     * Note: there is no limit to length, it keeps generating strings until length is reached...
     */
    static generateId(prefix = '', length = 11, postfix = '') {
        let id = Util.randomString;
        while (id.length < length)
            id = id + Util.randomString;
        return prefix + id.substring(0, length) + postfix;
    }
    /**
     * Generate amount of ids with the prefix, length and postfix.
     */
    static generateIds(amount, prefix = '', length = 11, postfix = '') {
        const ids = [];
        while (amount--)
            ids.push(Util.generateId(prefix, length, postfix));
        return ids;
    }
    /**
     * Generate a random id, with a optional prefix and postfix
     * @param prefix
     * @param postfix
     * @returns
     */
    static generateString(prefix = '', postfix = '') {
        return prefix + Util.randomString + postfix;
    }
}
exports.default = Util;
