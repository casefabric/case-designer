"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertTask = assertTask;
exports.verifyTaskInput = verifyTaskInput;
exports.findTask = findTask;
exports.assertTaskCount = assertTaskCount;
const config_1 = __importDefault(require("../../config"));
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
const stacktraceerror_1 = __importDefault(require("../../infra/stacktraceerror"));
const trace_1 = __importDefault(require("../../infra/trace"));
const logger_1 = __importDefault(require("../../logger"));
const taskservice_1 = __importDefault(require("../../service/task/taskservice"));
const comparison_1 = __importDefault(require("../comparison"));
const time_1 = require("../time");
/**
 * Asserts that the task has expected state, assignee, and owner
 * @param task
 * @param user
 * @param action
 * @param expectedState
 * @param expectedAssignee
 * @param expectedOwner
 */
function assertTask(user_1, task_1, action_1, expectedState_1, expectedAssignee_1, expectedOwner_1, expectedLastModifiedBy_1) {
    return __awaiter(this, arguments, void 0, function* (user, task, action, expectedState, expectedAssignee, expectedOwner, expectedLastModifiedBy, trace = new trace_1.default()) {
        return yield (0, time_1.PollUntilSuccess)(function () {
            return __awaiter(this, void 0, void 0, function* () {
                return yield taskservice_1.default.getTask(user, task).then(task => {
                    if (config_1.default.TestCase.log) {
                        logger_1.default.info(`Task after ${action}: state=${task.taskState}, assignee='${task.assignee}', owner='${task.owner}', modifiedBy='${task.modifiedBy}' `);
                    }
                    if (!expectedState.is(task.taskState)) {
                        throw new asyncerror_1.default(trace, `Task ${task.taskName} is not in state '${expectedState}' but in state '${task.taskState}'`);
                    }
                    if (expectedAssignee && task.assignee !== expectedAssignee.id) {
                        throw new asyncerror_1.default(trace, `Task ${task.taskName} is not assigned to '${expectedAssignee}' but to user '${task.assignee}'`);
                    }
                    if (expectedOwner && task.owner !== expectedOwner.id) {
                        throw new asyncerror_1.default(trace, `Task ${task.taskName} is not owned by '${expectedOwner}' but by '${task.owner}'`);
                    }
                    if (expectedLastModifiedBy && task.modifiedBy !== expectedLastModifiedBy.id) {
                        throw new asyncerror_1.default(trace, `Task ${task.taskName} is not last modified by '${expectedLastModifiedBy}' but by '${task.modifiedBy}'`);
                    }
                    return task;
                });
            });
        });
    });
}
/**
 * Verifies whether task's input is same as that of expected input
 * @param task
 * @param taskInput expected input
 */
function verifyTaskInput(task, taskInput) {
    if (!comparison_1.default.sameJSON(task.input, taskInput)) {
        throw new stacktraceerror_1.default(`Input for task ${task.taskName} is not expected;\nFound:    ${JSON.stringify(task.input)}\nExpected: ${JSON.stringify(taskInput)}`);
    }
}
/**
 * Finds and returns a particular task with in list of tasks
 * and throws an error if it does not exist
 * @param tasks
 * @param taskName
 */
function findTask(tasks, taskName) {
    const task = tasks.find(task => task.taskName === taskName);
    if (!task) {
        throw new stacktraceerror_1.default(`Cannot find task ${taskName}`);
    }
    return task;
}
/**
 * Asserts the number of tasks that have specified state with expected count
 * @param tasks
 * @param state
 * @param expectedCount
 */
function assertTaskCount(tasks, state, expectedCount) {
    const actualCount = tasks.filter(t => t.taskState === state).length;
    if (actualCount != expectedCount) {
        throw new stacktraceerror_1.default('Number of ' + state + ' tasks expected to be ' + expectedCount + '; but found ' + actualCount);
    }
}
