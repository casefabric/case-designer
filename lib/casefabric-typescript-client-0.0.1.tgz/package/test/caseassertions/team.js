"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertCaseTeam = assertCaseTeam;
exports.assertCaseTeamUser = assertCaseTeamUser;
exports.assertCaseTeamTenantRole = assertCaseTeamTenantRole;
exports.assertSameCaseTeamGroup = assertSameCaseTeamGroup;
const caseteamservice_1 = __importDefault(require("../../service/case/caseteamservice"));
const trace_1 = __importDefault(require("../../infra/trace"));
const asyncerror_1 = __importDefault(require("../../infra/asyncerror"));
function findMember(team, expectedMember) {
    return team.users.find(member => member.userId === expectedMember.userId);
}
function hasUser(team, expectedMember, expectNoDifferences = true, trace) {
    const differs = (msg) => {
        if (expectNoDifferences) {
            throw new asyncerror_1.default(trace, msg);
        }
    };
    const actualMember = findMember(team, expectedMember);
    if (!actualMember) {
        differs(`Case team does not contain a user '${expectedMember}'`);
        return;
    }
    // Check roles
    const actualRoles = actualMember.caseRoles;
    const expectedRoles = expectedMember.caseRoles;
    if (actualRoles && !expectedRoles) {
        differs(`Did not expect to find any case roles on team member ${expectedMember}, but found [${actualRoles}]`);
    }
    if (!actualRoles && expectedRoles) {
        differs(`Did not find any case roles on team member ${expectedMember}, expected [${expectedRoles}]`);
    }
    const missingRoles = expectedRoles.filter(expected => !actualRoles.find(role => role === expected));
    if (missingRoles.length > 0) {
        differs(`Team member ${expectedMember} misses expected roles ${missingRoles}`);
    }
    const unexpectedRoles = actualRoles.filter(actualRole => !expectedRoles.find(role => role === actualRole));
    if (unexpectedRoles.length > 0) {
        differs(`Team member ${expectedMember} is not expected to have roles [${unexpectedRoles}]`);
    }
    if (expectedMember.isOwner !== undefined && expectedMember.isOwner !== actualMember.isOwner) {
        differs(`Team member ${expectedMember} is${expectedMember.isOwner ? ' ' : ' not '}expected to be case owner`);
    }
    if (!expectNoDifferences) {
        throw new asyncerror_1.default(trace, `Member ${expectedMember} is unexpectedly present in the team`);
    }
}
function hasTenantRole(team, expectedTenantRole, expectNoDifferences = true, trace) {
    const differs = (msg) => {
        if (expectNoDifferences) {
            throw new asyncerror_1.default(trace, msg);
        }
    };
    const actualMember = team.tenantRoles.find(member => member.tenantRole === expectedTenantRole.tenantRole);
    if (!actualMember) {
        differs(`Case team does not contain a tenant role '${expectedTenantRole}'`);
        return;
    }
    // Check roles
    const actualRoles = actualMember.caseRoles;
    const expectedRoles = expectedTenantRole.caseRoles;
    if (actualRoles && !expectedRoles) {
        differs(`Did not expect to find case roles on tenant role ${expectedTenantRole}, but found [${actualRoles}]`);
    }
    if (!actualRoles && expectedRoles) {
        differs(`Did not find any case roles on tenant role ${expectedTenantRole}, expected [${expectedRoles}]`);
    }
    const missingRoles = expectedRoles.filter(expected => !actualRoles.find(role => role === expected));
    if (missingRoles.length > 0) {
        differs(`Tenant role ${expectedTenantRole} misses expected roles ${missingRoles}`);
    }
    const unexpectedRoles = actualRoles.filter(actualRole => !expectedRoles.find(role => role === actualRole));
    if (unexpectedRoles.length > 0) {
        differs(`Tenant role ${expectedTenantRole} is not expected to have roles [${unexpectedRoles}]`);
    }
    if (expectedTenantRole.isOwner !== undefined && expectedTenantRole.isOwner !== actualMember.isOwner) {
        differs(`Tenant role ${expectedTenantRole} is${expectedTenantRole.isOwner ? ' ' : ' not '}expected to be case owner`);
    }
    if (!expectNoDifferences) {
        throw new asyncerror_1.default(trace, `Tenant role ${expectedTenantRole} is unexpectedly present in the team`);
    }
}
function verifyTeam(actualTeam, expectedTeam, trace) {
    return __awaiter(this, void 0, void 0, function* () {
        const missingMembers = expectedTeam.users.filter(member => !findMember(actualTeam, member));
        const tooManyMembers = actualTeam.users.filter(member => !findMember(expectedTeam, member));
        // Simple case team member stringyfier that prints type of member and user id
        const membersPrinter = (members) => `[${members.join(', ')}]`;
        if (missingMembers.length > 0 && tooManyMembers.length > 0) {
            throw new Error(`Missing Case Team members ${membersPrinter(missingMembers)}, found unexpected users ${membersPrinter(tooManyMembers)}`);
        }
        if (missingMembers.length > 0) {
            throw new Error(`Expecting Case Team to contain ${expectedTeam.users.length} members, but found ${actualTeam.users.length}; missing members ${membersPrinter(missingMembers)}`);
        }
        if (tooManyMembers.length > 0) {
            throw new Error(`Expecting Case Team to contain ${expectedTeam.users.length} members, but found ${actualTeam.users.length}, with unexpected members ${membersPrinter(tooManyMembers)}`);
        }
        expectedTeam.users.forEach(expectedMember => hasUser(actualTeam, expectedMember, undefined, trace));
    });
}
/**
 * Asserts the case team with the given team
 * and throws error if it doesn't match
 * @param caseId
 * @param user
 * @param expectedTeam
 */
function assertCaseTeam(user_1, caseId_1, expectedTeam_1) {
    return __awaiter(this, arguments, void 0, function* (user, caseId, expectedTeam, trace = new trace_1.default()) {
        caseteamservice_1.default.getCaseTeam(user, caseId, undefined, undefined, trace).then(team => verifyTeam(team, expectedTeam, trace));
    });
}
/**
 * Asserts presence of the CaseTeamUser membership in the case team
 * @param member Member that must be present
 * @param caseId Case in which the member must be present
 * @param user User that retrieves the case team
 * @param expectNoDifferences Defaults to true, but can be set to false and then checks that the member may NOT be present in the team
 */
function assertCaseTeamUser(user_1, caseId_1, member_1) {
    return __awaiter(this, arguments, void 0, function* (user, caseId, member, expectNoDifferences = true, trace = new trace_1.default()) {
        // Get case team via getCaseTeam
        const actualCaseTeam = yield caseteamservice_1.default.getCaseTeam(user, caseId, undefined, undefined, trace);
        hasUser(actualCaseTeam, member, expectNoDifferences, trace);
    });
}
/**
 * Asserts presence of the CaseTeamTenantRole membership in the case team
 * @param member Member that must be present
 * @param caseId Case in which the member must be present
 * @param user User that retrieves the case team
 * @param expectNoDifferences Defaults to true, but can be set to false and then checks that the member may NOT be present in the team
 */
function assertCaseTeamTenantRole(user_1, caseId_1, member_1) {
    return __awaiter(this, arguments, void 0, function* (user, caseId, member, expectNoDifferences = true, trace = new trace_1.default()) {
        // Get case team via getCaseTeam
        const actualCaseTeam = yield caseteamservice_1.default.getCaseTeam(user, caseId, undefined, undefined, trace);
        hasTenantRole(actualCaseTeam, member, expectNoDifferences, trace);
    });
}
/**
 * Asserts presence of the CaseTeamGroup membership in the case team
 * @param member Member that must be present
 * @param caseId Case in which the member must be present
 * @param user User that retrieves the case team
 * @param expectNoDifferences Defaults to true, but can be set to false and then checks that the member may NOT be present in the team
 */
function assertSameCaseTeamGroup(user_1, caseId_1, member_1) {
    return __awaiter(this, arguments, void 0, function* (user, caseId, member, expectNoDifferences = true, trace = new trace_1.default()) {
        // Get case team via getCaseTeam
        const actualCaseTeam = yield caseteamservice_1.default.getCaseTeam(user, caseId, undefined, undefined, trace);
        hasGroup(actualCaseTeam, member, expectNoDifferences, trace);
    });
}
function hasGroup(team, expectedMember, expectNoDifferences = true, trace) {
    let foundDifferences = false;
    const differs = (msg) => {
        foundDifferences = true;
        if (expectNoDifferences) {
            throw new asyncerror_1.default(trace, msg);
        }
    };
    const actualMember = team.groups.find(group => group.groupId === expectedMember.groupId);
    if (!actualMember) {
        differs(`Case team does not contain a group '${expectedMember}'`);
        return;
    }
    // Check mappings of group roles
    const actualMappings = actualMember.mappings;
    const expectedMappings = expectedMember.mappings;
    if (actualMappings && !expectedMappings) {
        differs(`Did not expect to find mappings on case team group ${expectedMember}, but found [${actualMappings.map(m => m.groupRole)}]`);
    }
    if (!actualMappings && expectedMappings) {
        differs(`Did not find any mappings on case team group ${actualMember}, expected [${expectedMappings.map(m => m.groupRole)}]`);
    }
    const missingGroupRoleMappings = expectedMappings.filter(expected => !actualMappings.find(mapping => mapping.groupRole === expected.groupRole));
    if (missingGroupRoleMappings.length > 0) {
        differs(`Case Team Group ${expectedMember} misses expected group role mappings ${missingGroupRoleMappings.map(m => m.groupRole)}`);
    }
    const unexpectedGroupRoleMappings = actualMappings.filter(actualMapping => !expectedMappings.find(mapping => mapping.groupRole === actualMapping.groupRole));
    if (unexpectedGroupRoleMappings.length > 0) {
        differs(`Case Team Group ${expectedMember} is not expected to have group role mappings [${unexpectedGroupRoleMappings.map(m => m.groupRole)}]`);
    }
    expectedMappings.forEach(expectedMapping => {
        const actualMapping = actualMappings.find(mapping => mapping.groupRole === expectedMapping.groupRole);
        if (!actualMapping) {
            differs(`Case Team Group ${expectedMember} misses expected group role mapping ${expectedMapping.groupRole}`);
        }
        if (expectedMapping.isOwner !== undefined && expectedMapping.isOwner !== (actualMapping === null || actualMapping === void 0 ? void 0 : actualMapping.isOwner)) {
            differs(`Case Team Group ${expectedMember} with mapping for group role ${expectedMapping.groupRole} iss ${expectedMapping.isOwner ? ' ' : ' not '} expected to be case owner`);
        }
        // Check roles
        const actualRoles = actualMapping === null || actualMapping === void 0 ? void 0 : actualMapping.caseRoles;
        const expectedRoles = expectedMapping.caseRoles;
        if (actualRoles && !expectedRoles) {
            differs(`Case Team Group ${expectedMember} is not supposed to have case roles for group role mapping ${expectedMapping.groupRole}, but found [${actualRoles}]`);
        }
        if (!actualRoles && expectedRoles) {
            differs(`Case Team Group ${expectedMember} is not having expected case roles for group role mapping ${expectedMapping.groupRole}, expected [${expectedRoles}]`);
        }
        const missingRoles = expectedRoles.filter(expected => !(actualRoles === null || actualRoles === void 0 ? void 0 : actualRoles.find(role => role === expected)));
        if (missingRoles.length > 0) {
            differs(`Case Team Group ${expectedMember} misses roles ${missingRoles} for group role mapping ${expectedMapping.groupRole}`);
        }
        const unexpectedRoles = actualRoles === null || actualRoles === void 0 ? void 0 : actualRoles.filter(actualRole => !expectedRoles.find(role => role === actualRole));
        if (unexpectedRoles && unexpectedRoles.length > 0) {
            differs(`Case Team Group ${expectedMember} is not expected to have roles [${unexpectedRoles}] for group role mapping ${expectedMapping.groupRole}`);
        }
    });
    if (!expectNoDifferences && !foundDifferences) {
        throw new asyncerror_1.default(trace, `Case Team Group ${expectedMember} is unexpectedly present in the team`);
    }
}
