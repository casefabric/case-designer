"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const consentgroupmember_1 = require("../../service/consentgroup/consentgroupmember");
const consentgroupservice_1 = __importDefault(require("../../service/consentgroup/consentgroupservice"));
const platformservice_1 = __importDefault(require("../../service/platform/platformservice"));
const tenant_1 = __importDefault(require("../../tenant/tenant"));
const tenantuser_1 = __importStar(require("../../tenant/tenantuser"));
const util_1 = __importDefault(require("../../test/util"));
class RandomTenant extends tenant_1.default {
    constructor(prefix = 'random_tenant_', users = []) {
        super(util_1.default.generateId(prefix, 5), users);
        this.groups = [];
    }
    addUser(user) {
        this.users.push(new RandomTenantUser(user));
        return user;
    }
    create(platformOwner) {
        return __awaiter(this, void 0, void 0, function* () {
            const findOwner = () => {
                const existingUser = this.users.find(u => u.id === platformOwner.id);
                if (existingUser) {
                    return existingUser;
                }
                else {
                    const newUser = new tenantuser_1.TenantOwner(platformOwner.id, []);
                    this.users.push(newUser);
                    return newUser;
                }
            };
            this.owner = findOwner();
            this.owner.isOwner = true;
            yield this.owner.login();
            yield platformservice_1.default.createTenant(this.owner, this);
            yield this.groups.forEach((group) => __awaiter(this, void 0, void 0, function* () {
                yield this.createGroup(group);
                yield group.members.forEach((member) => __awaiter(this, void 0, void 0, function* () { return yield member.login(); }));
            }));
            yield this.users.forEach((user) => __awaiter(this, void 0, void 0, function* () { return yield user.login(); }));
        });
    }
    /**
     * Add a group that is owned by at least the tenant owner.
     * @param group
     */
    addGroup(group) {
        this.groups.push(group);
        return group;
    }
    /**
     * Add a group that is owned by at least the tenant owner.
     * @param group
     */
    createGroup(group) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.owner) {
                throw new Error('Owner is not yet available for creation of group');
            }
            const groupOwner = group.members.find(m => { var _a; return m.id === ((_a = this.owner) === null || _a === void 0 ? void 0 : _a.id); });
            if (groupOwner) {
                groupOwner.isOwner = true; // Enforce it to be a group owner
            }
            else {
                group.members.push(new consentgroupmember_1.ConsentGroupOwner(this.owner.id));
            }
            yield consentgroupservice_1.default.createGroup(this.owner, this, group);
        });
    }
}
exports.default = RandomTenant;
class RandomTenantUser extends tenantuser_1.default {
    constructor(user) {
        super(user.id, user.roles);
        this.user = user;
    }
    login() {
        const _super = Object.create(null, {
            login: { get: () => super.login }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield this.user.login();
            return _super.login.call(this);
        });
    }
}
