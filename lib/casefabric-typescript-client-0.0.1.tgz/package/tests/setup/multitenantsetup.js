"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_1 = __importDefault(require("../../user"));
const tenantuser_1 = __importStar(require("../../tenant/tenantuser"));
const tenant_1 = __importDefault(require("../../tenant/tenant"));
const platformservice_1 = __importDefault(require("../../service/platform/platformservice"));
const consentgroup_1 = __importDefault(require("../../service/consentgroup/consentgroup"));
const consentgroupservice_1 = __importDefault(require("../../service/consentgroup/consentgroupservice"));
/**
 * Somewhat complexer tenant setup, along with consent groups
 */
class MultiTenantSetup {
    constructor(platformAdmin = new user_1.default('admin')) {
        this.platformAdmin = platformAdmin;
        // Create users, and collect the in tenant users groups.
        this.girl = new tenantuser_1.TenantOwner('girl', ['Daughter', 'Family']);
        this.boy = new tenantuser_1.TenantOwner('boy', ['Son', 'Family']);
        this.dad = new tenantuser_1.default('dad', ['Father', 'Family']);
        this.mom = new tenantuser_1.default('mom', ['Mother', 'Family']);
        this.neil = new tenantuser_1.default('neil', ['Captain', 'Astronaut']);
        this.buzz = new tenantuser_1.default('buzz', ['Astronaut']);
        this.irwin = new tenantuser_1.default('irwin', ['Astronaut']);
        this.elon = new tenantuser_1.default('elon', ['Captain', 'Star']);
        this.jeff = new tenantuser_1.default('jeff', ['Captain', 'Shepherd']);
        this.alien = new tenantuser_1.default('alien', ['Alien']);
        this.martian = new tenantuser_1.default('martian', ['Alien', 'Martian']);
        this.people = [this.girl, this.boy, this.dad, this.mom, this.neil, this.buzz, this.irwin, this.elon, this.jeff, this.alien];
        this.moonmen = createMoonFamily([this.neil, this.buzz, this.irwin, this.alien]); // These users have role 'Family', but only in moon tenant.
        this.martians = [this.girl, this.boy, this.elon, this.jeff, this.alien, this.martian];
        // Create tenants
        this.world = new tenant_1.default('world-tenant', this.people);
        this.moon = new tenant_1.default('moon-tenant', this.moonmen);
        this.mars = new tenant_1.default('mars-tenant', this.martians);
        this.futureWorld = new tenant_1.default('family-world-tenant', [this.girl, this.boy, this.dad, this.mom]);
        // Note: same role name in different groups has a different meaning!
        //  We give it the same name just to ensure that this does not lead to authorization issues (e.g., being member of different group with same role name should not give you access)
        this.groupRoleUser = 'user';
        this.groupRoleTester = 'tester';
        // Create consent groups
        this.moonGroup = new consentgroup_1.default([this.neil.asCGO(), this.buzz.asCGM(this.groupRoleUser), this.alien.asCGM(this.groupRoleTester)], 'moon-group');
        this.marsGroup = new consentgroup_1.default([this.jeff.asCGO(), this.boy.asCGM(this.groupRoleUser), this.alien.asCGM(this.groupRoleTester)], 'mars-group');
        this.marsGroup2 = new consentgroup_1.default([this.boy.asCGO(), this.elon.asCGM(this.groupRoleUser), this.martian.asCGM(this.groupRoleTester)], 'mars-group2');
    }
    /**
     * Creates the tenant, and logs in for sender user and receiver user.
     */
    create() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.platformAdmin.login();
            yield platformservice_1.default.createTenant(this.platformAdmin, this.world);
            yield platformservice_1.default.createTenant(this.platformAdmin, this.moon);
            yield platformservice_1.default.createTenant(this.platformAdmin, this.mars);
            yield platformservice_1.default.createTenant(this.platformAdmin, this.futureWorld);
            yield this.girl.login();
            yield this.boy.login();
            yield this.mom.login();
            yield this.dad.login();
            yield this.neil.login();
            yield this.buzz.login();
            yield this.irwin.login();
            yield this.elon.login();
            yield this.jeff.login();
            yield this.alien.login();
            yield this.martian.login();
            yield consentgroupservice_1.default.createGroup(this.neil, this.moon, this.moonGroup);
            yield consentgroupservice_1.default.createGroup(this.boy, this.mars, this.marsGroup);
            yield consentgroupservice_1.default.createGroup(this.boy, this.mars, this.marsGroup2);
            // Additionally get the groups, to since ConsentGroupLastModified 
            //  is not taken into account when running e.g. StartCase.
            yield consentgroupservice_1.default.getGroup(this.neil, this.moonGroup);
            yield consentgroupservice_1.default.getGroup(this.boy, this.marsGroup);
            yield consentgroupservice_1.default.getGroup(this.boy, this.marsGroup2);
        });
    }
}
exports.default = MultiTenantSetup;
function createMoonFamily(users) {
    // Copy all passed users, make the first one tenant owner, and also give all of them the 'Family' role
    const family = users.map((user, index) => {
        const newUser = new tenantuser_1.default(user.id);
        if (index === 0)
            newUser.isOwner = true;
        newUser.roles.push('Family', ...user.roles);
        return newUser;
    });
    return family;
}
