"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tenantuser_1 = __importDefault(require("../../tenant/tenantuser"));
const util_1 = __importDefault(require("../../test/util"));
class RandomUser extends tenantuser_1.default {
    constructor(id = util_1.default.generateId('random_user_', 5), roles = []) {
        super('' + id, roles);
    }
}
exports.default = RandomUser;
