"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const consentgroup_1 = __importDefault(require("../../service/consentgroup/consentgroup"));
const consentgroupmember_1 = __importDefault(require("../../service/consentgroup/consentgroupmember"));
const util_1 = __importDefault(require("../../test/util"));
const randomuser_1 = __importDefault(require("./randomuser"));
class RandomGroup extends consentgroup_1.default {
    constructor(prefix = 'random_group_', members = []) {
        super(members, util_1.default.generateId(prefix, 5));
    }
    addMember(user = new randomuser_1.default(), roles = []) {
        const member = this.members.find(member => member.id === user.id);
        if (member) {
            return member;
        }
        else {
            const newMember = new RandomGroupMember(user, roles);
            this.members.push(newMember);
            return newMember;
        }
    }
}
exports.default = RandomGroup;
class RandomGroupMember extends consentgroupmember_1.default {
    constructor(user, roles) {
        super(user.id, roles);
        this.user = user;
    }
    login() {
        const _super = Object.create(null, {
            login: { get: () => super.login }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield this.user.login();
            return _super.login.call(this);
        });
    }
}
